<?php include('global-variables.php') ?>



<?php foreach($terms_structure as $structure){?>
<?php include($website.'/'.$structure.'.php') ?>
<?php } ?>
