<?php
$website = "web5";
include($website.'/variables/plans.php');
include($website.'/variables/site_setting.php');