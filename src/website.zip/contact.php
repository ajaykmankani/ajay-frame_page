<?php include('global-variables.php') ?>



<?php foreach($contact_structure as $structure){?>
<?php include($website.'/'.$structure.'.php') ?>
<?php } ?>
