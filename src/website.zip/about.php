<?php include('global-variables.php') ?>



<?php foreach($about_structure as $structure){?>
<?php include($website.'/'.$structure.'.php') ?>
<?php } ?>
