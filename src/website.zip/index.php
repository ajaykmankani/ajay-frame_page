<?php include('global-variables.php') ?>



<?php foreach($index_structure as $structure){?>
<?php include($website.'/'.$structure.'.php') ?>
<?php } ?>
