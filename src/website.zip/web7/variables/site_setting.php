<?php


$sitename = "Vrismeta Communication";
$phone = "+1 (866) 618-5384";
$phone_tel = "+18666185384";
$logo = "web5/images/logo2.png";
$mail = "contact@vrismetacommunication.com";
$address ="35640 56th Ave S Auburn 98001 WA";

$index_structure = array(
'includes/header',
'index/banner',
'index/plan1',
'index/plan6',
'index/contactBar',
'index/plan5',
'index/plan2',
'index/topChannles',
'includes/footer',
);

$about_structure = array(

    'includes/header',
    'about/content',
    'includes/footer',

    );

    $contact_structure = array(

        'includes/header',
        'contact/content',
        'includes/footer',

    );
    $privacy_structure = array(

        'includes/header',
        'privacy/content',
        'includes/footer',

    );

    $terms_structure = array(

        'includes/header',
        'terms/content',
        'includes/footer',

    );

?>