<section class="section-three space">
    <div class="container space">
        <div class="row d-flex align-items-center justify-content-center">
        <div class="col-lg-6 col-md-6 text-start">
        <p style="text-align:justify;"  class="highlight-text fs-5 fw-bold">INTERNET</p>
            <h2 class="txt-b">Customize & Book Affordable Price on Every Products with<br>
                <span class="txt-light-b">TV and Internet Technology</span>
            </h2>
        </div>
        <div class="col-lg-6 col-md-6 mt-2">
        <p style="text-align:justify;">Stream All Your Favourite TV Channels On Multiple Devices.
            </p>
            <button class="myBtn top-btn mt-4 fs-5"><a href="tel:<?=$phone_tel?>" class="text-white">Request Business Services</a></button>
        </div>
     </div>
        <div class="row">
            <div class="co-md-12 text-center">
                <img src="images/product-img.jpg" alt="product img">
            </div>
        </div>

 </div>

</section>

