<section class="channels space" id="slidedown">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h2 class="txt-b">TOP CHANNELS</h2>
                <p>Regional sports networks, hit movies, original series, and more—our TV packages have the essential channels you want.</p>
                <img src="web5/images/channles.jpeg" alt="channles" class="my-2">
            </div>
        </div>
    </div>
</section>