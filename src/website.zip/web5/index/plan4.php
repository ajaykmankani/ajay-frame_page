
<section class="section-three space" style=" background-image: url(images/img-5.2.png);
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center; height:750px; width: 100%;">
    <div class="container space">



    <div class="row d-flex align-items-center justify-content-center">

        <div class="col-md-6">
        <img src="" alt="">
        <p style="text-align:justify;"  class="highlight-text fs-5 fw-bold">TELEVISION</p>
        <h3 class="txt-light-b">Flexible Plans</h3>
                    <p style="text-align:justify;" class="text-white">Looking For High Speed Internet For Home & Work?
                    </p>
                <ul class="list">
                                    <li class="px-2 text-white"><img src="images/checked.png" alt="checked"> Lorem ipsum dolor sit amet.</li>
                                    <li class="px-2 text-white"><img src="images/checked.png" alt="checked"> Lorem ipsum dolor sit amet.</li>
                                    <li class="px-2 text-white"><img src="images/checked.png" alt="checked"> Lorem ipsum dolor sit amet.</li>
                                    <li class="px-2 text-white"><img src="images/checked.png" alt="checked"> Lorem ipsum dolor sit amet.</li>
                                    <li class="px-2 text-white"><img src="images/checked.png" alt="checked"> Lorem ipsum dolor sit amet.</li>
                                    <li class="px-2 text-white"><img src="images/checked.png" alt="checked"> Lorem ipsum dolor sit amet.</li>
                                </ul>
                <button class="myBtn top-btn mt-4 fs-5"><a href="tel:<?=$phone_tel?>" class="text-white">Learn More</a></button>
        </div>
        <div class="col-md-6">
            <img src="images/tv-remote.png" alt="tv remote" class="remote">
        </div>
    </div>

    </div>
</section>

