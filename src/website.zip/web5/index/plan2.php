<section class="plan2-section space">
    <div class="container">

        <div class="row mt-5">
      
          
            <div class="col-md-6 ">
                <img class="rounded" src="web5/images/s3.jpg" alt="img2">
            </div>
      

            <div class="col-md-6">
                <div class="planheading">
                <em class="">WHO WE ARE</em>
                    <h3 class="fs-1 fw-bolder mt-2">Get TV service with your internet service</h3>
                

                    <p style="text-align:justify">Get Premium Channels
Free For 3 Months
With Every New Connection</p>
                   
                    <button class="btn btn-call-head mt-4" type="btn btn-primary"><a href="tel:<?=$phone_tel?>">Know More</a></button>




                </div>
            </div>

       </div>

     
    </div>
</section>