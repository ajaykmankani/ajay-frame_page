<div class="sec-info  space">
<div class="container">
        <div class="row d-flex align-items-center justify-content-center">
            <div class="col-md-10">
                
                <h3 class="text-white mt-2">Let's find deals and services | Fast Support | Available 24/7</h3>

            </div>
            <div class="col-md-2">
            <a href="tel:<?=$phone_tel?>" class="bar-btn1 text-white mt-2">Get Now</a>
            </div>
        </div>
    </div>
</div>