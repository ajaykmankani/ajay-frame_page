<section class="section-one Banner" style=" background-image: url(web5/images/head-banner.png);
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center; height:750px; width: 100%;">

        <div class="container space">
            <div class="row">
                <div class="col-md-7">
<h1 class="text-white banner-h1 slide-up fw-bold" id="my-element"><span class="highlight-text">Save money </span></h1>
<h2 class="text-white fs-1">by bundling your internet service with <span class="highlight-text"> TV service.</span>.</h2>
<p class="text-white fs-4" >Watch 160+ Popular TV Channels Save More on Bundle Get A Quote Now!</p>
<button class="btn btn-call-head" type="btn btn-primary"><a href="tel:<?=$phone_tel?>">Know More</a></button>
                </div>
<div class="col-md-5"></div>
            </div>
        </div>
    </section>