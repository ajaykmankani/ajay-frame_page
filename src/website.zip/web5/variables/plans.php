<?php

$plan1 = array(
        array(
        'title'=>'Broadband',
        'sub_title' => 'Get Premium Channels
        Free For 3 Months
        With Every New Connection',
        'color'=>'#f3663f',
        'link' => 'Get Broadband Service ➝',

        ),
        array(
        'title'=>'Satelite TV',
        'sub_title' => 'Stream All Your Favourite TV Channels On Multiple Devices.',
        'color'=>'#ffffff',
        'link' => 'Get Satelite TV Service ➝',
        ),
        array(
         'title'=>'Home Phone',
         'sub_title' => 'Looking For High Speed Internet For Home & Work?',
         'color'=>'#ffffff',
         'link' => 'Get Home Phone Services ➝',
            ),
        
        );




//======================================================================================//


        $plan5 = array(

            array(
               
                'title' => 'STREAMING TV',
                'price' => '$69.99/mo. + taxes',
                'sub_title' =>  '',
              
            
                'list' => array(

                  
                  "75+ channels of live TV",
                  "40,000+ On Demand titles",
                  "Get unlimited hours of Cloud DVR",
                  "Save $30 over 2 months!",
                  "No Contract Required",
                     
                ),
                'link' => 'Get Started',
                
            ),
            array(
               
                'title' => 'SATELLITE TV',
                'price' => '$64.99/mo. + taxes',
                'sub_title' =>  '',
                
                
                'list' => array(
                  
                    " Includes 160+ popular TV channels",
                    "Store over 200 hr of HD recording",
                    "Includes 3 months of premium channels",
                    "Over 99% proven Reliability",
                    "$100 reward card on New connection",
                      
                     
                ),
                'link' => 'Get Started',
                
            ),
            array(
               
                'title' => 'FIBER INTERNET',
                'price' => '$55/mo. + taxes',
                'sub_title' =>  '',
               
                
                'list' => array(

                    "15X faster upload & more bandwidth",
                    "Uncapped internet data included",
                    "Free WiFi Device & Installation",
                    "Over 99% proven Reliability",
                    "No Contract Required",
                      
                     
                     
                ),
                'link' => 'Get Started',
                
            ),
            
        
        );



        $plan6 = array(

            array(
               
                'title' => 'Get Premium Channels
                Free For 3 Months
                With Every New Connection',
                'price' => '$69.99/mo. + taxes',
                'sub_title' =>  'Get first 3 months of HBO Max™, Cinemax®
                SHOWTIME®, STARZ®, and EPIX®',
              
            
                'list' => array(

                  
                  "Includes 160+ popular HDTV channels",
                  "Store over 200 hr of HD recording",
                  "Includes 3 months of premium channels",
                  "Over 99% proven Reliability",
                  "$100 reward card on New connection",
                     
                ),
                'link' => 'Get Started',
                
            ),
            array(
               
                'title' => 'Stream All Your Favourite TV Channels On Multiple Devices.',
                'price' => '$64.99/mo. + taxes',
                'sub_title' =>  'Stream All Your Favourite TV Channels On Multiple Devices.',
                
                
                'list' => array(
                  
                    " 75+ Live TV Channels",
                    "40,000+ On Demand titles",
                    "Watch More of Live Sports",
                    "Save $30 over 2 months!",
                    "No Contract Required",
                      
                     
                ),
                'link' => 'Get Started',
                
            ),
            array(
               
                'title' => 'Looking For High Speed Internet For Home & Work?',
                'price' => '$55/mo. + taxes',
                'sub_title' =>  'Call Now to order Fiber Internet with speed from 300-1000 MBPS!',
               
                
                'list' => array(

                    "15X faster upload & more bandwidth",
                    "Uncapped internet data included",
                    "Free WiFi Device & Installation",
                    "Over 99% proven Reliability",
                    "No Contract Required",
                      
                     
                     
                ),
                'link' => 'Get Started',
                
            ),
            
        
        );
        

?>