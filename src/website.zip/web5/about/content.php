
<hr>
<section class="form-footer space mt-5">

<div class="container">
<div class="row d-flex align-items-center justify-content-center">

        <div class="col-md-12">
            <h2 class="">About Us</h2>
          
            <p style="text-align:justify;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi quis deserunt ab at eaque minima culpa unde quos repellat nostrum, ratione debitis, consequatur quo aliquid eos, impedit possimus qui corrupti libero autem odit labore tempora.p>
        </div>
    </div>
  
    <div class="row mt-4 d-flex align-items-center justify-content-center">
        <div class="col-md-6">
       <img class="rounded" src="web5/images/imm.jpg" alt="imm">
        </div>
        <div class="col-md-6">
            <h2 class="highlight-text">Our History</h2>
          
            <p style="text-align:justify;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi quis deserunt ab at eaque minima culpa unde quos repellat nostrum, ratione debitis, consequatur quo aliquid eos, impedit possimus qui corrupti libero autem odit labore tempora. </p>
        </div>
    </div>
</div>

</section>