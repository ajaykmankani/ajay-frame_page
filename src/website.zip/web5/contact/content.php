
<hr>
<section class="form-footer space mt-5">

        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <h2 class="">Contact <span class="highlight-text">Information</span></h2>

                    <p class="mt-4 " style="text-align:justify;">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Laborum nemo iusto consequatur distinctio adipisci, optio unde corrupti nesciunt temporibus labore?</p>
                    <hr>
                    <p><strong>Phone Number:</strong> <?=$phone?><p>
                        <hr>
                        <p><strong>Location:</strong> <?=$address?><p>
                        <hr>
                        <p><strong>Email Address:</strong> <?=$mail?><p>
                </div>
                <div class="col-md-7">
                    <img class="rounded" src="web5/images/imm.jpg" alt="imm">
                </div>

            </div>
        </div>

</section>