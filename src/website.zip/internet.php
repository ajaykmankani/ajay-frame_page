<?php include('global-variables.php') ?>



<?php foreach($internet_structure as $structure){?>
<?php include($website.'/'.$structure.'.php') ?>
<?php } ?>
